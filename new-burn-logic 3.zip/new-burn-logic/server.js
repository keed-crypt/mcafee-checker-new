const express = require('express');
const cors = require('cors');  // Import CORS middleware
const app = express();
const dotenv = require('dotenv');
const bodyParser = require('body-parser');

// Load environment variables
dotenv.config();

// Use CORS middleware with wildcard for all origins temporarily
app.use(cors({ origin: '*' })); // This allows all origins

// Handle preflight requests for all routes (OPTIONS method)
app.options('*', cors()); // This ensures CORS is set for preflight requests (necessary for POST requests)

// Middleware for parsing JSON bodies
app.use(bodyParser.json());

const indexLogic = require('./index');

// API endpoint
app.post('/calculate', async (req, res) => {
  const { tokenMint } = req.body;
  if (!tokenMint) {
    return res.status(400).send({ error: 'tokenMint is required' });
  }

  try {
    const result = await indexLogic(tokenMint);
    res.json(result);
  } catch (error) {
    res.status(500).send({ error: 'Something went wrong' });
  }
});

// Start the server on the provided port (Heroku sets process.env.PORT)
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
