const express = require('express');
const app = express();
const dotenv = require('dotenv');
const bodyParser = require('body-parser');

// Load environment variables from .env file
dotenv.config();

// Middleware for parsing JSON bodies
app.use(bodyParser.json());

const indexLogic = require('./index'); // Import the logic from index.js

// API endpoint to interact with the Solana contract
app.post('/calculate', async (req, res) => {
  const { tokenMint } = req.body;
  if (!tokenMint) {
    return res.status(400).send({ error: 'tokenMint is required' });
  }

  try {
    // Execute the logic from index.js
    const result = await indexLogic(tokenMint);
    res.json(result);
  } catch (error) {
    res.status(500).send({ error: 'Something went wrong' });
  }
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
