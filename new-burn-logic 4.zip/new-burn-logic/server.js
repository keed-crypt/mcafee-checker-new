const express = require('express');
const cors = require('cors');
const app = express();
const dotenv = require('dotenv');
const bodyParser = require('body-parser');

// Load environment variables
dotenv.config();

// Use CORS middleware
app.use(cors({
  origin: '*',  // Allow all origins
  methods: ['GET', 'POST', 'OPTIONS'],  // Allow GET, POST, OPTIONS methods
  allowedHeaders: '*',  // Allow all headers
}));

// Handle preflight requests explicitly
app.use((req, res, next) => {
  if (req.method === 'OPTIONS') {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
    res.header('Access-Control-Allow-Headers', '*');
    return res.sendStatus(200);
  }
  next();
});

// Middleware for parsing JSON bodies
app.use(bodyParser.json());

// Import your token handling logic (assuming index.js contains the logic)
const indexLogic = require('./index');

// API endpoint
app.post('/calculate', async (req, res) => {
  const { tokenMint } = req.body;

  if (!tokenMint) {
    return res.status(400).send({ error: 'tokenMint is required' });
  }

  try {
    const result = await indexLogic(tokenMint);
    res.json(result);
  } catch (error) {
    res.status(500).send({ error: 'Something went wrong' });
  }
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
