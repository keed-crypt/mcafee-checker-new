const { gql, GraphQLClient } = require("graphql-request");
const solana = require('@solana/web3.js');
const promptSync = require("prompt-sync");

// Initialize prompt-sync for user input
const prompt = promptSync();

// Configurations for API endpoints
const apiKey = "zeEVxN5d6lQsWBD_";
const gqlEndpoint = `https://programs.shyft.to/v0/graphql/?api_key=${apiKey}`;
const rpcEndpoint = `https://rpc.shyft.to/?api_key=${apiKey}`;

const graphQLClient = new GraphQLClient(gqlEndpoint, {
  method: 'POST',
  jsonSerializer: {
    parse: JSON.parse,
    stringify: JSON.stringify,
  },
});

const connection = new solana.Connection(rpcEndpoint);

// Fetch liquidity pool information by token mint (as either base or quote)
async function queryLpByToken(tokenMint) {
  const query = gql`
    query MyQuery($where: Raydium_LiquidityPoolv4_bool_exp) {
      Raydium_LiquidityPoolv4(
        where: $where
      ) {
        lpMint
        lpReserve
        baseMint
        quoteMint
      }
    }`;

  const variables = {
    where: {
      _or: [
        { baseMint: { _eq: tokenMint } },
        { quoteMint: { _eq: tokenMint } },
      ],
    },
  };

  return await graphQLClient.request(query, variables);
}

// Function to calculate burn percentage
function getBurnPercentage(lpReserve, actualSupply) {
  const maxLpSupply = Math.max(actualSupply, (lpReserve - 1));
  const burnAmt = maxLpSupply - actualSupply;
  console.log(`Burn Amount: ${burnAmt}`);
  return (burnAmt / maxLpSupply) * 100;
}

// Main function to calculate burn percentage based on token input
async function calculateBurnPercentage() {
  try {
    // Prompt the user for token mint
    const tokenMint = prompt("Please enter the token mint address: ");
    
    // Fetch the liquidity pool info using the provided token mint
    const info = await queryLpByToken(tokenMint);
    console.log("API Response: ", info);

    if (!info || !info.Raydium_LiquidityPoolv4 || info.Raydium_LiquidityPoolv4.length === 0) {
      console.error("No pool information found.");
      return;
    }

    // Assume we are taking the first pool returned for simplicity
    const lpMint = info.Raydium_LiquidityPoolv4[0].lpMint;
    const lpReserveRaw = info.Raydium_LiquidityPoolv4[0].lpReserve;

    // Get the current supply and decimals for lpMint
    const parsedAccInfo = await connection.getParsedAccountInfo(new solana.PublicKey(lpMint));
    const mintInfo = parsedAccInfo?.value?.data?.parsed?.info;

    if (!mintInfo) {
      console.error("Failed to fetch mint info.");
      return;
    }

    const decimals = mintInfo.decimals;
    const lpReserve = lpReserveRaw / Math.pow(10, decimals);
    const actualSupply = mintInfo.supply / Math.pow(10, decimals);

    // Display mint authority status
    const mintAuthorityStatus = mintInfo.mintAuthority ? "Enabled" : "Disabled";
    console.log(`Mint Authority: ${mintAuthorityStatus}`);

    // Display freeze authority status
    const freezeAuthorityStatus = mintInfo.freezeAuthority ? "Enabled" : "Disabled";
    console.log(`Freeze Authority: ${freezeAuthorityStatus}`);

    console.log(`LP Mint: ${lpMint}, Reserve: ${lpReserve}, Actual Supply: ${actualSupply}`);

    // Calculate burn percentage
    const burnPct = getBurnPercentage(lpReserve, actualSupply);
    console.log(`Burn Percentage: ${burnPct.toFixed(1)}% LP burned`);

  } catch (error) {
    console.error("Error fetching or calculating burn percentage:", error);
  }
}

// Start the script
calculateBurnPercentage();
